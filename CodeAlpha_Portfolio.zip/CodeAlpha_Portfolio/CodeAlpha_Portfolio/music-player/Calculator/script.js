const result = document.getElementById('result');

function appendToDisplay(value) {
    result.value += value;
}

function clearScreen() {
    result.value = '';
}

function deleteLast() {
    result.value = result.value.slice(0, -1);
}

function calculate() {
    try {
        result.value = eval(result.value
            .replace('×', '*')
            .replace('−', '-')
        );
    } catch (e) {
        result.value = 'Error';
        setTimeout(() => { result.value = ''; }, 1500);
    }
}

// BONUS: Keyboard support
document.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') calculate();
    if (e.key === 'Backspace') deleteLast();
    if (e.key === 'Escape') clearScreen();
    
    if ('0123456789.+-*/'.includes(e.key)) {
        appendToDisplay(e.key === '*' ? '×' : e.key === '/' ? '/' : e.key);
    }
});